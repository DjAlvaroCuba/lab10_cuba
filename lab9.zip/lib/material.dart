import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('Mostrar Imagen Local'),
        ),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Image.asset('assets/images/catito.jpeg'),
              SizedBox(height: 20),
              Text(
                'Texto con fuente Jacquard',
                style: TextStyle(
                  fontFamily: 'Jacquard',
                  fontSize: 20,
                ),
              ),
              SizedBox(height: 20),
              Text(
                'Texto con fuente Roboto regular',
                style: TextStyle(
                  fontSize: 20,
                  fontFamily: 'Roboto-Bold',
                ),
              ),
              SizedBox(height: 20),
              Text(
                'Texto con fuente Normal Bugo Renzo',
                style: TextStyle(
                  fontSize: 20,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
